#
# Arquivo com exemplos de manipulação de  datas
#

from datetime import date, time, datetime 
